<?php
   

	class General{

		private $db;

		public function __construct(){
			require_once($_SERVER['DOCUMENT_ROOT'] . '/CU-clearance_portal/includes/config.php');
			$this->db = $pdo;
		}

		/*** for login process ***/
		public function check_login($username){

			$query = "SELECT * from reglist WHERE matno='$username'";
			$stmt = $this->db->prepare($query);
			$row_count = $this->db->query("select count(*) from reglist WHERE matno='$username'")->fetchColumn(); 
			$stmt->execute();
			
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$_SESSION['regno'] = $username;


			return $row_count;

            
    	}

		public function getStudentRecords(){

			$query = "SELECT * FROM `reglist`";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

				echo '
				
				<tr>
					<td>'.$row["matno"].'</td>
					<td>
					'.$row["fno"].'
					</td>
					<td>'.$row["sex"].'</td>
					<td>'.$row["college"].'</td>
					<td>'.$row["dept"].'</td>
					<td>'.$row["program"].'</td>
					<td>'.$row["level"].'</td>
					<td>'.ucwords($row["fname"]).'</td>
					<td>
						<a href="student_profile.php?matno='.$row["matno"].'" class="btn btn-info" title="View  profile">
							<i class="fa fa-eye" aria-hidden="true"></i> 
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getCsisStudentRecords(){

			$query = "SELECT * FROM `reglist`";
			$stmt = $this->db->prepare($query);
			$stmt->execute();


			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

				echo '
				
				<tr>
					<td>'.$row["matno"].'</td>
					<td>
					'.$row["fno"].'
					</td>
					<td>'.$row["sex"].'</td>
					<td>'.$row["college"].'</td>
					<td>'.$row["dept"].'</td>
					<td>'.$row["program"].'</td>
					<td>'.$row["level"].'</td>
					<td>'.ucwords($row["fname"]).'</td>
					<td>
						<a href="csis_profile.php?matno='.$row["matno"].'" class="btn btn-info" title="View  profile">
							<i class="fa fa-eye" aria-hidden="true"></i> 
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getClearanceDepartmentsForm($dept) {
			$query = "SELECT * FROM exitclerancedepts where clerance_department = '$dept'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$deptid = $row['deptid'];

			$_SESSION['deptid'] = $deptid;


			
			$query = "SELECT * FROM exitclearancedeptitems where deptid = '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			$row_items = $stmt->fetch(PDO::FETCH_ASSOC);

			


			$ids[] = null;

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$ids[] = (object)['itemid' => $row['itemid'], 'deptid' => $row['deptid']];
				// echo '
				// <div class="form-group">
					
				// 	<label for="">'.$row['itemname'].'</label>
				// 	<input type="text" name="'.$row['itemname'].'" class="form-control" width="70%" placeholder="">
				// </div>
				// ';
			}

			$_SESSION['items'] = $ids;
		}
		public function getClearanceDept(){

				$query = "SELECT * FROM exitclerancedepts";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
					
					echo '
					
					<tr>
						<td>'.$row["clerance_department"].'</td>
					
						<td>
							<a href="add_clearance_dept_table.php?clearance_dept='.$row["deptid"].'" class="btn btn-info" title="View  profile">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="add_clearance_dept_table.php?status=delete&clearance_dept_id='.$row["deptid"].'" class="btn btn-danger" title="Delete Department">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>

						<td>
							<a href="add_dept_items.php?clerance_department='.$row["clerance_department"].'&clearance_dept_id='.$row["deptid"].'" class="btn btn-info" title="Add  Items to this department">
								<i class="fa fa-plus" aria-hidden="true"></i> 
							</a>
						</td>

						<td>
							<a href="view_dept_items.php?clerance_department='.$row["clerance_department"].'&clearance_dept_id='.$row["deptid"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function addDeptItems($item_id, $item_name, $item_status, $ddate, $deptid ) {
				$item_id = $deptid . $item_id;
				$sql = "INSERT INTO  exitclearancedeptitems (itemid, deptid, itemname, itemstatus, ddate) VALUES ('$item_id', '$deptid', '$item_name', '$item_status', '$ddate')";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function getExitClearanceKickOffTableNames(){

				$query = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'cu_db' AND TABLE_NAME = 'exitclearanceickoff'			";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				$row = $stmt->fetch(PDO::FETCH_ASSOC);

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["COLUMN_NAME"].'</td>
						<td>
							<a href="create_clearance_table.php?old_column_name='.$row["COLUMN_NAME"].'" class="btn btn-info" title="Edit  Column">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="create_clearance_table.php?column_name='.$row["COLUMN_NAME"].'" class="btn btn-danger" title="Delete  Column">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>
						
					</tr>
					';
				}
				
			}
			
			public function getDepartmentItems($deptId){

				$query = "SELECT * FROM exitclearancedeptitems WHERE deptid = '$deptId'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();


			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["itemname"].'</td>
						<td>'.$row["itemstatus"].'</td>
						<td>'.$row["ddate"].'</td>
						<td>
							<a href="create_clearance_table.php?old_column_name='.$row["deptid"].'" class="btn btn-info" title="Edit  Item">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="add_dept_items.php?clerance_department='.$row["itemname"].'&clearance_dept_id=30&status=delete&item_id='.$row["itemid"].'" class="btn btn-danger" title="Delete  Item">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>
						
					</tr>
					';
				}
				
			}
			public function getDepartmentsSerialNumbers(){

				$query = "SELECT * FROM  departments";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				$row = $stmt->fetch(PDO::FETCH_ASSOC);

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
						<option value="'.$row['dpno'].'">'.$row['dpno'].'</option>
					';
				}
				
			}
			public function updateClearanceDept ($status, $follow_order, $dept, $order_no, $deptid) {

				$query = "UPDATE exitclerancedepts SET clerance_department = '$dept', followorder = '$follow_order', deptstatus = '$status', orderno = '$order_no'  WHERE deptid = '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				if($stmt){
					return true;
				}else {
					false;
				}
			}
			public function getKickoffRecords(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

			

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="csis_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			
			public function getClearanceDepartments($deptid) {
				$query = "SELECT * from  exitclerancedepts  where deptid = '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				
				if($row){
					return $row;
				}
			}
			public function deleteClearanceDepartment($deptid) {
				$query = "DELETE FROM `exitclerancedepts` WHERE deptid= '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				
				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			
			public function deleteDepartmentItems($itemid) {
				$query = "DELETE FROM `exitclearancedeptitems` WHERE itemid= '$itemid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				
				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function getAStudentRecord($student_id){
				
				$query = "SELECT * from exitclearanceickoff , reglist where exitclearanceickoff.regno = '$student_id' AND reglist.matno = '$student_id'
				";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				
				if($row){
					return $row;
				}
			}

			public function get_programs(){
				$query = "SELECT * FROM `programs`";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
					echo '
						<option value="'.$row["program"].'">'.$row["program"].'</option>
					';
				}
			}
			public function getKickoffRecordsFinance(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

			

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="finance_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			
			public function dropTableColumn($columnName){
				$tableName = 'exitclearanceickoff';
				$columnName = $columnName;
				$sql = "ALTER TABLE  `$tableName` DROP  `$columnName`";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function updateColumnName ($oldColumnName, $newColumnName) {
				$tableName = 'exitclearanceickoff';
				$columnName = $oldColumnName;
				$sql = "ALTER TABLE `exitclearanceickoff` CHANGE `$oldColumnName` `$newColumnName` VARCHAR(255)  NULL";

				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function createNewExitClearancKickoffDBItem($column, $type){

				$sql = '';

				$tableName = 'exitclearanceickoff';
				
				$columnName = $column;

				if($type === 'int'){
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` INT(255)  NULL";
				}else if($type === 'varchar') {
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` varchar(255)  NULL";
				}else if($type === 'string'){
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` text(1000)  NULL";
				}

				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			
			
			public function addClearanceDept($status, $follow_order, $dept, $order_no){

				$sql = "INSERT INTO  exitclerancedepts (clerance_department, followorder, deptstatus, orderno) VALUES ('$dept', '$follow_order', '$status', '$order_no')";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}


			public function addCSISRecords($registration_Clearance, $equipment_damge_clearance, $other_service_charges, $others, $deptid, $kickoffid , $reg_no) {
				// Process Equipment Damage Clearance
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Equipment Damage Clearance'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date('d-m-y');


				$itemId = $row['itemid'];

				$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES (1, '$kickoffid', '$reg_no', '$deptid','$itemId', '$equipment_damge_clearance', 0, $tdatetime)";
				$stmt = $this->db->query($sql);

				// Process Other Service Charges
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Other Service Charges'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date('d-m-y');


				$itemId = $row['itemid'];

				$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES (1, '$kickoffid', '$reg_no', '$deptid','$itemId', '$other_service_charges', 0, $tdatetime)";
				$stmt = $this->db->query($sql);

				// Process Others Field
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Others'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date('d-m-y');


				$itemId = $row['itemid'];

				$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES (1, '$kickoffid', '$reg_no', '$deptid','$itemId', '$others', 0, $tdatetime)";
				$stmt = $this->db->query($sql);

				// Process  Registration Clearance Field
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Registration Clearance'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date('d-m-y');


				$itemId = $row['itemid'];

				$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES (1, '$kickoffid', '$reg_no', '$deptid','$itemId', '$registration_Clearance', 0, $tdatetime)";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}


			public function saveStudentClearanceRecords($reg_no, $clearance_reason, $semester_id){

				if($clearance_reason === 'request for transcript'){
					
					$checkForDuplicateTranscriptRequest = $this->checkForDuplicateTranscriptRequest($reg_no, $clearance_reason, $semester_id);
					if($checkForDuplicateTranscriptRequest == 1) {
						return false;
					}else {
						$sql = "INSERT INTO  exitclearanceickoff (regno, clearancereason, semesterid) VALUES ('$reg_no', '$clearance_reason', '$semester_id')";
						$stmt = $this->db->query($sql);

						if($stmt){
							return true;
						}else {
							return false;
						}
					}
				}else {
					$sql = "INSERT INTO  exitclearanceickoff (regno, clearancereason, semesterid) VALUES ('$reg_no', '$clearance_reason', '$semester_id')";
						$stmt = $this->db->query($sql);

						if($stmt){
							return true;
						}else {
							return false;
						}
				}
				
			}

			public function checkForDuplicateTranscriptRequest($reg_no, $clearance_reason, $semester_id){
				$query = "SELECT * from exitclearanceickoff  where regno = '$reg_no' and semesterid = '$semester_id' and clearancereason = '$clearance_reason'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				if($row > 0){
					return true;
				}else {
					return false;
				}
			}

		
		}


?>