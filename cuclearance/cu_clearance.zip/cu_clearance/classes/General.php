<?php
   

	class General{

		private $db;

		public function __construct(){
			require_once($_SERVER['DOCUMENT_ROOT'] . '/includes/config.php');
			$this->db = $pdo;
		}

		/*** for login process ***/
		public function check_login($username){

			echo $username;

			$query = "SELECT * from reglist WHERE matno='$username'";
			$stmt = $this->db->prepare($query);
			$row_count = $this->db->query("select count(*) from reglist WHERE matno='$username'")->fetchColumn(); 
			$stmt->execute();
			
			$row = $stmt->fetch(PDO::FETCH_ASSOC);


			if($row_count == 1){
				session_start();
				$_SESSION['regno'] = $username;
				header("location: ../change_of_program/change_program.php");
				return $row_count;
			}

		}
		public function checkStaffLogin($deptid){
			echo $deptid;

			$query = "SELECT * from appointmenthistory where unit = '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			session_start();
			$_SESSION['pc_deptid'] = $deptid;
			$_SESSION['dept'] = $row['remark'];
			header("location: ../change_of_program/view_program_change_requests.php");
			return $row_count;
		}
		

		public function getStudentProfile($matno){
			// reg clearance status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Registration Clearance'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['reg_status'] = $row['itemcleared'];
			$_SESSION['reg_comment'] = $row['itemcomment'];

			// Equipment Damage Clearance
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Equipment Damage Clearance'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['edc_status'] = $row['itemcleared'];
			$_SESSION['edc_comment'] = $row['itemcomment'];

			// Others
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Others'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['o_status'] = $row['itemcleared'];
			$_SESSION['o_comment'] = $row['itemcomment'];

			// Other Service Charges
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Other Service Charges'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['osc_status'] = $row['itemcleared'];
			$_SESSION['osc_comment'] = $row['itemcomment'];
		}
		public function getFinanceRecords($matno){
			// Tution Related Fees status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Tution Related Fees'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['trf_status'] = $row['itemcleared'];
			$_SESSION['trf_comment'] = $row['itemcomment'];

			// Make-up Resit/Late Registration charges Clearance
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Make-up Resit/Late Registration charges'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['mur_status'] = $row['itemcleared'];
			$_SESSION['mur_comment'] = $row['itemcomment'];

			// CMFB Loan
			$query = "SELECT * from exitclearancedeptitems where itemname = 'CMFB Loan'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['cmfb_status'] = $row['itemcleared'];
			$_SESSION['cmfb_comment'] = $row['itemcomment'];

			// Laptop Loan
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Laptop Loan'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['ll_status'] = $row['itemcleared'];
			$_SESSION['ll_comment'] = $row['itemcomment'];

			// Personal Financial Integrity
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Personal Financial Integrity'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['pfi_status'] = $row['itemcleared'];
			$_SESSION['pfi_comment'] = $row['itemcomment'];

			// Others
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Others'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['others_fin_status'] = $row['itemcleared'];
			$_SESSION['others_comment'] = $row['itemcomment'];

			// Staff Guarantee	
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Staff Guarantee'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['sg_status'] = $row['itemcleared'];
			$_SESSION['sg_comment'] = $row['itemcomment'];
		}
		public function getHealthStatus($matno){
			// reg clearance status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Hall Damages'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['hd_status'] = $row['itemcleared'];
			$_SESSION['hd_comment'] = $row['itemcomment'];

			// Pending Disciplinary case
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Pending Disciplinary case'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['pdc_status'] = $row['itemcleared'];
			$_SESSION['pdc_comment'] = $row['itemcomment'];

			// Sport Center Clearance
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Sport Center Clearance'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['scc_status'] = $row['itemcleared'];
			$_SESSION['scc_comment'] = $row['itemcomment'];

		}
		public function getAcademicStudentProfile($matno){
			// Books Damaged status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Books Outstanding	'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['bo_status'] = $row['itemcleared'];
			$_SESSION['bo_comment'] = $row['itemcomment'];

			// Bills for damage Resources status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Bills For Damaged Resources'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['bfdr_status'] = $row['itemcleared'];
			$_SESSION['bfdr_comment'] = $row['itemcomment'];

			
		}
		public function getCLRStudentProfile($matno){
			// reg clearance status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'CLR'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['acad_req_status'] = $row['itemcleared'];
			$_SESSION['acad_req_comment'] = $row['itemcomment'];

			
		}

		public function getHealthDeptRecords($matno){
			// Fully Registered status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Fully registered'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['fr_status'] = $row['itemcleared'];
			$_SESSION['fr_comment'] = $row['itemcomment'];

			// Bills for damage Resources status
			$query = "SELECT * from exitclearancedeptitems where itemname = 'Outstanding Medical Bill'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$itemid = $row['itemid'];

			$query = "SELECT * from exitclerancetransaction where itemid = '$itemid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute(); 
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			
			$_SESSION['omb_status'] = $row['itemcleared'];
			$_SESSION['omb_comment'] = $row['itemcomment'];

			
		}
		public function getStudentRecords(){

			$query = "SELECT * FROM `reglist`";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

				echo '
				
				<tr>
					<td>'.$row["matno"].'</td>
					<td>
					'.$row["fno"].'
					</td>
					<td>'.$row["sex"].'</td>
					<td>'.$row["college"].'</td>
					<td>'.$row["dept"].'</td>
					<td>'.$row["program"].'</td>
					<td>'.$row["level"].'</td>
					<td>'.ucwords($row["fname"]).'</td>
					<td>
						<a href="student_profile.php?matno='.$row["matno"].'" class="btn btn-info" title="View  profile">
							<i class="fa fa-eye" aria-hidden="true"></i> 
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getProgramChangeRequests(){

			$query = "SELECT * FROM `changeofprogrammerequest`";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				

				echo '
				
				<tr>
					<td>'.$row["regno"].'</td>
					<td>
					'.$row["newprogram"].'
					</td>
					<td>'.$row["oldprogram"].'</td>
					<td>'.$row["newlevel"].'</td>
					<td>'.$row["oldlevel"].'</td>
					<td>'.$row["changeremarks"].'</td>
					<td>'.$row["requeststatus"].'</td>
					<td>
						<a href="program_change_request_details.php?matno='.$row["regno"].'" class="btn btn-info" title="View  Details">
							<i class="fa fa-eye" aria-hidden="true"></i> 
							View
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getStudentsBeingAccepted(){

			$deptid = $_SESSION['pc_deptid'];
			$query = "SELECT * FROM `changeofprogrammerequest` where new_dept_id =  '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				

				echo '
				
				<tr>
					<td>'.$row["regno"].'</td>
					<td>
					'.$row["newprogram"].'
					</td>
					<td>'.$row["oldprogram"].'</td>
					<td>'.$row["newlevel"].'</td>
					<td>'.$row["oldlevel"].'</td>
					<td>'.$row["changeremarks"].'</td>
					<td>'.$row["requeststatus"].'</td>
					<td>
						<a href="program_change_request_details.php?matno='.$row["regno"].'" class="btn btn-info" title="View  Details">
							<i class="fa fa-eye" aria-hidden="true"></i> 
							View
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getStudentsBeingReleased(){

			$deptid = $_SESSION['pc_deptid'];
			$query = "SELECT * FROM `changeofprogrammerequest` where old_dept_id =  '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				

				echo '
				
				<tr>
					<td>'.$row["regno"].'</td>
					<td>
					'.$row["newprogram"].'
					</td>
					<td>'.$row["oldprogram"].'</td>
					<td>'.$row["newlevel"].'</td>
					<td>'.$row["oldlevel"].'</td>
					<td>'.$row["changeremarks"].'</td>
					<td>'.$row["requeststatus"].'</td>
					<td>
						<a href="program_change_request_details.php?matno='.$row["regno"].'" class="btn btn-info" title="View  Details">
							<i class="fa fa-eye" aria-hidden="true"></i> 
							View
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getSameDeptStudents(){

			$deptid = $_SESSION['pc_deptid'];
			$query = "SELECT * FROM `changeofprogrammerequest` where old_dept_id =  '$deptid' and new_dept_id = '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				

				echo '
				
				<tr>
					<td>'.$row["regno"].'</td>
					<td>
					'.$row["newprogram"].'
					</td>
					<td>'.$row["oldprogram"].'</td>
					<td>'.$row["newlevel"].'</td>
					<td>'.$row["oldlevel"].'</td>
					<td>'.$row["changeremarks"].'</td>
					<td>'.$row["requeststatus"].'</td>
					<td>
						<a href="program_change_request_details.php?matno='.$row["regno"].'" class="btn btn-info" title="View  Details">
							<i class="fa fa-eye" aria-hidden="true"></i> 
							View
						</a>
					</td>
				</tr>
				';
			}
            
		}

		public function getCsisStudentRecords(){

			$query = "SELECT * FROM `reglist`";
			$stmt = $this->db->prepare($query);
			$stmt->execute();


			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

				echo '
				
				<tr>
					<td>'.$row["matno"].'</td>
					<td>
					'.$row["fno"].'
					</td>
					<td>'.$row["sex"].'</td>
					<td>'.$row["college"].'</td>
					<td>'.$row["dept"].'</td>
					<td>'.$row["program"].'</td>
					<td>'.$row["level"].'</td>
					<td>'.ucwords($row["fname"]).'</td>
					<td>
						<a href="csis_profile.php?matno='.$row["matno"].'" class="btn btn-info" title="View  profile">
							<i class="fa fa-eye" aria-hidden="true"></i> 
						</a>
					</td>
				</tr>
				';
			}
            
		}
		public function getClearanceDepartmentsForm($dept) {
			$query = "SELECT * FROM exitclerancedepts where clerance_department = '$dept'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$deptid = $row['deptid'];

			$_SESSION['deptid'] = $deptid;


			
			$query = "SELECT * FROM exitclearancedeptitems where deptid = '$deptid'";
			$stmt = $this->db->prepare($query);
			$stmt->execute();

			$row_items = $stmt->fetch(PDO::FETCH_ASSOC);

			


			$ids[] = null;

			while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				$ids[] = (object)['itemid' => $row['itemid'], 'deptid' => $row['deptid']];
				// echo '
				// <div class="form-group">
					
				// 	<label for="">'.$row['itemname'].'</label>
				// 	<input type="text" name="'.$row['itemname'].'" class="form-control" width="70%" placeholder="">
				// </div>
				// ';
			}

			$_SESSION['items'] = $ids;
		}
		public function getClearanceDept(){

				$query = "SELECT * FROM exitclerancedepts";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
					
					echo '
					
					<tr>
						<td>'.$row["clerance_department"].'</td>
					
						<td>
							<a href="add_clearance_dept_table.php?clearance_dept='.$row["deptid"].'" class="btn btn-info" title="View  profile">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="add_clearance_dept_table.php?status=delete&clearance_dept_id='.$row["deptid"].'" class="btn btn-danger" title="Delete Department">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>

						<td>
							<a href="add_dept_items.php?clerance_department='.$row["clerance_department"].'&clearance_dept_id='.$row["deptid"].'" class="btn btn-info" title="Add  Items to this department">
								<i class="fa fa-plus" aria-hidden="true"></i> 
							</a>
						</td>

						<td>
							<a href="view_dept_items.php?clerance_department='.$row["clerance_department"].'&clearance_dept_id='.$row["deptid"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function addDeptItems($item_id, $item_name, $item_status, $ddate, $deptid ) {
				$item_id = $deptid . $item_id;

				$item_id = uniqid();
				$sql = "INSERT INTO  exitclearancedeptitems (itemid, deptid, itemname, itemstatus, ddate) VALUES ('$item_id', '$deptid', '$item_name', '$item_status', '$ddate')";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function getExitClearanceKickOffTableNames(){

				$query = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'cu_db' AND TABLE_NAME = 'exitclearanceickoff'			";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				$row = $stmt->fetch(PDO::FETCH_ASSOC);

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["COLUMN_NAME"].'</td>
						<td>
							<a href="create_clearance_table.php?old_column_name='.$row["COLUMN_NAME"].'" class="btn btn-info" title="Edit  Column">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="create_clearance_table.php?column_name='.$row["COLUMN_NAME"].'" class="btn btn-danger" title="Delete  Column">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>
						
					</tr>
					';
				}
				
			}
			
			public function getDepartmentItems($deptId){

				$query = "SELECT * FROM exitclearancedeptitems WHERE deptid = '$deptId'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();


			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["itemname"].'</td>
						<td>'.$row["itemstatus"].'</td>
						<td>'.$row["ddate"].'</td>
						<td>
							<a href="add_dept_items.php?itemid='.$row["deptid"].'&action=edit" class="btn btn-info" title="Edit  Item">
								<i class="fa fa-edit" aria-hidden="true"></i> 
							</a>
						</td>
						<td>
							<a href="add_dept_items.php?clerance_department='.$row["itemname"].'&clearance_dept_id='.$deptId.'&status=delete&item_id='.$row["itemid"].'" class="btn btn-danger" title="Delete  Item">
								<i class="fa fa-trash" aria-hidden="true"></i> 
							</a>
						</td>
						
					</tr>
					';
				}
				
			}

			public function editDeptItems($itemid) {
				$query = "UPDATE  exitclearancedeptitems SET itemname = '$itemname' WHERE itemid = '$itemid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				if($stmt){
					return true;
				}else {
					false;
				}
			}
			public function updateStudentRequest($matno, $cr, $deptid, $staffrole, $request_id , $oldlevel,$newLevel, $semesterid, $oldprogram, $newprogram) {
				
				// GET OLD  PROGRAM ID
				$query = "SELECT * from  programs  where program = '$oldprogram'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$old_prog_id = $row['prgid'];

				// GET NEW  PROGRAM ID
				$query = "SELECT * from  programs  where program = '$newprogram'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$new_prog_id = $row['prgid'];

				// GET STUDENT CHANGE TYPE
				$query = "SELECT * from  changeofprogrammefee  where regno = '$matno'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$changetype = $row['changetype'];
				
				$tdatetime = date("Y-m-d h:i:sa");


				// Isert into transaction table
				$sql = "INSERT INTO  changeofprogrammetrans (changetypeid, requestid, regno, staffrole, changeremarks, changeapproval, oldprgid, newprgid, oldlevel, newlevel, semid, transdatetime) VALUES ('$changetype', '$request_id', '$matno', '$staffrole','$cr', 'Processing', '$old_prog_id', '$new_prog_id', '$oldlevel', '$newLevel', '$semesterid', '$tdatetime')";
				$stmt = $this->db->query($sql);

				// Update requests
				$deptid = $_SESSION['pc_deptid'];
				$query = "UPDATE   changeofprogrammerequest SET changeremarks = '$cr', requeststatus = 'Processing' , deptid = '$deptid', staff_role = '$staffrole' WHERE regno = '$matno'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				if($stmt){
					return true;
				}else {
					false;
				}
			}
			public function getDepartmentsSerialNumbers(){

				$query = "SELECT * FROM  departments";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				$row = $stmt->fetch(PDO::FETCH_ASSOC);

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
						<option value="'.$row['dpno'].'">'.$row['dpno'].'</option>
					';
				}
				
			}
			public function updateClearanceDept ($status, $follow_order, $dept, $order_no, $deptid) {

				$query = "UPDATE exitclerancedepts SET clerance_department = '$dept', followorder = '$follow_order', deptstatus = '$status', orderno = '$order_no'  WHERE deptid = '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				if($stmt){
					return true;
				}else {
					false;
				}
			}
			public function getKickoffRecords(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="csis_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function getKickOffRecordsForFinancialServices(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="fs_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function getKickoffForStudentAffairsDept(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="sa_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function getKickoffRecordsForAcademicDept(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="acad_dept_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function getKickoffDetailsForHealthCenter(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="medical_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			public function getKickoffRecordsForCLR(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="clr_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			
			public function getClearanceDepartments($deptid) {
				$query = "SELECT * from  exitclerancedepts  where deptid = '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				
				if($row){
					return $row;
				}
			}
			public function deleteClearanceDepartment($deptid) {
				$query = "DELETE FROM `exitclerancedepts` WHERE deptid= '$deptid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				
				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			
			public function deleteDepartmentItems($itemid) {
				$query = "DELETE FROM `exitclearancedeptitems` WHERE itemid= '$itemid'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

				
				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function getAStudentRecord($student_id){
				
				$query = "SELECT * from exitclearanceickoff , reglist where exitclearanceickoff.regno = '$student_id' AND reglist.matno = '$student_id'
				";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				
				if($row){
					return $row;
				}
			}
			public function getStudentRequestDetails($student_id){

				$query = "SELECT * from changeofprogrammerequest , reglist where changeofprogrammerequest.regno = '$student_id' AND reglist.matno = '$student_id'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);
				
				if($row){
					return $row;
				}
			}

			public function get_programs(){
				$query = "SELECT * FROM `programs`";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
					echo '
						<option value="'.$row["program"].'">'.$row["program"].'</option>
					';
				}
			}
			public function getDeptId(){
				$query = "SELECT * FROM `appointmenthistory`";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
					echo '
						<option value="'.$row["unit"].'">'.$row["remark"].'</option>
					';
				}
			}
			public function getKickoffRecordsFinance(){

				$query = "SELECT * FROM exitclearanceickoff";
				$stmt = $this->db->prepare($query);
				$stmt->execute();

			

			
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

					echo '
					
					<tr>
						<td>'.$row["regno"].'</td>
						<td>'.$row["clearancereason"].'</td>
						<td>'.$row["semesterid"].'</td>
						<td>
							<a href="finance_profile.php?matno='.$row["regno"].'" class="btn btn-info" title="View Items in this Department">
								<i class="fa fa-eye" aria-hidden="true"></i> 
							</a>
						</td>
					</tr>
					';
				}
				
			}
			
			public function dropTableColumn($columnName){
				$tableName = 'exitclearanceickoff';
				$columnName = $columnName;
				$sql = "ALTER TABLE  `$tableName` DROP  `$columnName`";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function updateColumnName ($oldColumnName, $newColumnName) {
				$tableName = 'exitclearanceickoff';
				$columnName = $oldColumnName;
				$sql = "ALTER TABLE `exitclearanceickoff` CHANGE `$oldColumnName` `$newColumnName` VARCHAR(255)  NULL";

				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			public function createNewExitClearancKickoffDBItem($column, $type){

				$sql = '';

				$tableName = 'exitclearanceickoff';
				
				$columnName = $column;

				if($type === 'int'){
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` INT(255)  NULL";
				}else if($type === 'varchar') {
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` varchar(255)  NULL";
				}else if($type === 'string'){
					$sql = "ALTER TABLE  `$tableName` ADD  `$columnName` text(1000)  NULL";
				}

				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}
			
			
			public function addClearanceDept($status, $follow_order, $dept, $order_no){

				$sql = "INSERT INTO  exitclerancedepts (clerance_department, followorder, deptstatus, orderno) VALUES ('$dept', '$follow_order', '$status', '$order_no')";
				$stmt = $this->db->query($sql);

				if($stmt){
					return true;
				}else {
					return false;
				}
			}


			public function addCSISRecords($reg_clearance, $equipment_damge_clearance, $other_service_charges, $others, $deptid, $kickoffid , $row_no, $reg_action,$osc_action, $o_action,  $edc_action) {

				// Process Equipment Damage Clearance
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Equipment Damage Clearance'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];


				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$equipment_damge_clearance', itemcleared = '$edc_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$equipment_damge_clearance', '$edc_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				
				// Process Other Service Charges
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Other Service Charges'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$other_service_charges', itemcleared = '$osc_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$other_service_charges', '$osc_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				

				// Process Others Field
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Others'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$others', itemcleared = '$o_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$others', '$o_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				// Process  Registration Clearance Field
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Registration Clearance'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$reg_clearance', itemcleared = '$reg_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$reg_clearance', '$reg_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}
			public function addFiancialServicesRecords($kickoffid,$ll, $cmfb, $others , $trf, $pfi, $mur, $sg , $ll_action, $cmfb_action, $others_action, $sg_action, $trf_action, $pfi_action, $mur_action,  $deptid, $row_no) {

				// Process Laptop Loan
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Laptop Loan'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];


				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$ll', itemcleared = '$ll_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$ll', '$ll_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				
				// Process Other Service Charges
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Tution Related Fees'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$trf', itemcleared = '$trf_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$trf', '$trf_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				

				// Make-up Resit/Late Registration charges
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Make-up Resit/Late Registration charges'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$mur', itemcleared = '$mur_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$mur', '$mur_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				// Process  CMFB Loan
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'CMFB Loan'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$cmfb', itemcleared = '$cmfb_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$cmfb', '$cmfb_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				// Process  Staff Guarantee
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Staff Guarantee'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$sg', itemcleared = '$sg_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$cmfb', '$sg_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				// Personal Financial Integrity
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Personal Financial Integrity'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$sg', itemcleared = '$pfi_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$cmfb', '$pfi_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

					// Personal Others
					$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Others'";
					$stmt = $this->db->prepare($query);
					$stmt->execute();
					$row = $stmt->fetch(PDO::FETCH_ASSOC);
	
					$tdatetime = date("Y-m-d h:i:sa");
	
	
					$itemId = $row['itemid'];
	
					$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
					$stmt = $this->db->prepare($query);
					$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
					$stmt->execute();
					$row = $stmt->fetch(PDO::FETCH_ASSOC);
	
					$transId = uniqid();
	
					if($row_count){
						$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$row_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$others', itemcleared = '$others_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
						$stmt = $this->db->query($sql);
					}else {
						$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$row_no', '$deptid','$itemId', '$others', '$others_action', '$tdatetime')";
						$stmt = $this->db->query($sql);
					}
				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}
			public function addHealthCenterRecords($hd, $pdc, $scc, $deptid, $kickoffid , $regno, $hd_action, $pdc_action, $scc_action ) {

				// Process Hall Damages
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Hall Damages'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];


				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$regno', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$hd', itemcleared = '$hd_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$regno', '$deptid','$itemId', '$hd', '$hd_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				
				// Process Other Service Charges
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Pending Disciplinary case'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$regno', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$pdc', itemcleared = '$pdc_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$regno', '$deptid','$itemId', '$pdc', '$pdc_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				

				// Process Sport Center Clearance
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Sport Center Clearance'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");


				$itemId = $row['itemid'];

				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$regno', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$scc', itemcleared = '$scc_action', tdatetime = '$tdatetime'   where itemid = '$itemId'";
					$stmt = $this->db->query($sql);
				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$regno', '$deptid','$itemId', '$scc', '$scc_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

			

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}
			public function addAcademicDepartmentRecords($academic_requirement, $deptid, $kickoffid , $reg_no, $acad_req_action) {
				
				// Process Equipment Damage Clearance
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Academic Requirement'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];



				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$reg_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$academic_requirement', itemcleared = '$acad_req_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$reg_no', '$deptid','$itemId', '$academic_requirement', '$acad_req_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}
			public function addClrDepartmentRecord($books_outstanding, $bills_for_damaged_resources,  $deptid, $kickoffid , $reg_no, $bfdr_action, $bo_action) {

				echo $bills_for_damaged_resources;
				echo $books_outstanding;
				
				// Process books_outstanding
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Books  Outstanding'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				

				$itemId = $row['itemid'];



				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$reg_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$books_outstanding', itemcleared = '$bo_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$reg_no', '$deptid','$itemId', '$books_outstanding', '$bo_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}
				// Process Bill Outstanding
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Bills For Damaged Resources'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];




				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();


			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$reg_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$bills_for_damaged_resources', itemcleared = '$bfdr_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$reg_no', '$deptid','$itemId', '$bills_for_damaged_resources', '$bfdr_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}
			public function addMedicalClearanceRecords($omb, $fr,  $deptid, $kickoffid , $reg_no, $omb_action, $fr_action) {

				
				// Process Outstanding Medical Bill
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Outstanding Medical Bill'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");

				$itemId = $row['itemid'];
				



				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();

			

				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$reg_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$omb', itemcleared = '$omb_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$reg_no', '$deptid','$itemId', '$omb', '$omb_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				// Process FUlly Registered
				$query = "SELECT * from  exitclearancedeptitems  where deptid = '$deptid' and itemname = 'Fully registered'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$tdatetime = date("Y-m-d h:i:sa");
				


				$itemId = $row['itemid'];




				$query = "SELECT * from  exitclerancetransaction  where itemid = '$itemId'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("SELECT * from  exitclerancetransaction  where itemid = '$itemId'")->fetchColumn(); 
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$transId = uniqid();


				if($row_count){
					$sql = "UPDATE exitclerancetransaction 	SET transactionid = '$transId', kickoffid = '$kickoffid', regno = '$reg_no', deptid = '$deptid' ,   itemid = '$itemId', itemcomment = '$fr', itemcleared = '$fr_action', tdatetime = '$tdatetime'  where itemid = '$itemId'";
					$stmt = $this->db->query($sql);

				}else {
					$sql = "INSERT INTO  exitclerancetransaction (transactionid, kickoffid, regno, deptid, itemid,itemcomment, itemcleared, tdatetime) VALUES ('$transId', '$kickoffid', '$reg_no', '$deptid','$itemId', '$fr', '$fr_action', '$tdatetime')";
					$stmt = $this->db->query($sql);
				}

				if($stmt){
					return true;
				}else {
					return false;
				}

				
			}

			public function applyForChangeOfProgram($amount, $rowno, $old_level, $new_level, $old_program, $new_progam,	$semester, $change_type){

				// Get Old Program department Id
				$query = "SELECT * from  programs  where program = '$old_program'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$old_deptid = $row['deptid'];


				// Get New Program department Id
				$query = "SELECT * from  programs  where program = '$new_progam'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				$new_deptid = $row['deptid'];


				$isChangeInitiated = $this->checkForMultipleChangeOfProgramRequests($rowno);



				if($isChangeInitiated) {
					return false;
				}else {
					$date = date("Y-m-d h:i:sa");

					$sql = "INSERT INTO  changeofprogrammefee (changetype, amount, regno, feedatetime) VALUES ('$change_type', '$amount', '$rowno', '$date')";
					
					$stmt = $this->db->query($sql);

					$sql = "INSERT INTO  changeofprogrammerequest (regno, newprogram, oldprogram, oldlevel, newlevel, semesterid, requestdatetime, old_dept_id, new_dept_id) VALUES ('$rowno', '$new_progam', '$old_program', '$old_level','$new_level', '$semester' , '$date', '$old_deptid', '$new_deptid')";
					$stmt = $this->db->query($sql);

					if($stmt){
						return true;
					}else {
						return false;
					}
				}

				
			}

			public function checkForMultipleChangeOfProgramRequests($matno){
				$query = "SELECT * from changeofprogrammerequest WHERE regno='$matno'";
				$stmt = $this->db->prepare($query);
				$row_count = $this->db->query("select count(*) from changeofprogrammerequest WHERE regno='$matno'")->fetchColumn(); 
				$stmt->execute();


				
				if($row_count > 1){
					return true;
				}else {
					return false;
				}
			}

			public function saveStudentClearanceRecords($row_no, $clearance_reason, $semester_id){

				if($clearance_reason === 'request for transcript'){
					
					$checkForDuplicateTranscriptRequest = $this->checkForDuplicateTranscriptRequest($row_no, $clearance_reason, $semester_id);
					if($checkForDuplicateTranscriptRequest == 1) {
						return false;
					}else {
						$sql = "INSERT INTO  exitclearanceickoff (regno, clearancereason, semesterid) VALUES ('$row_no', '$clearance_reason', '$semester_id')";
						$stmt = $this->db->query($sql);

						if($stmt){
							return true;
						}else {
							return false;
						}
					}
				}else {
					$sql = "INSERT INTO  exitclearanceickoff (regno, clearancereason, semesterid) VALUES ('$row_no', '$clearance_reason', '$semester_id')";
						$stmt = $this->db->query($sql);

						if($stmt){
							return true;
						}else {
							return false;
						}
				}
				
			}

			public function checkForDuplicateTranscriptRequest($row_no, $clearance_reason, $semester_id){
				$query = "SELECT * from exitclearanceickoff  where regno = '$row_no' and semesterid = '$semester_id' and clearancereason = '$clearance_reason'";
				$stmt = $this->db->prepare($query);
				$stmt->execute();
				$row = $stmt->fetch(PDO::FETCH_ASSOC);

				if($row > 0){
					return true;
				}else {
					return false;
				}
			}

		
		}


?>